
namespace Graphics
{
	public partial class GUI
	{
		private void Build()
		{
		}
	}
}
